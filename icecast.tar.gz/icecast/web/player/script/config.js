var auth_root = 'https://auth.bigtunesradio.com/action_encoder.php';
