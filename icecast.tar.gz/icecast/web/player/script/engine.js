(function($){
    $.ajax({
        type: "POST",
        url: auth_root,
        data: "action=load&mount=" + window.location.search.replace('?mount=', ''),
        success: function(data) {
            $("#rulestable").html(data);
        }
    });
})(jQuery);
